// Script para processar lucros diários dos investimentos
// Este script deve ser executado diariamente via Cron Job

export default {
  async scheduled(event, env, ctx) {
    try {
      const db = env.DB

      // Buscar todos os investimentos ativos
      const activeInvestments = await db
        .prepare(`
        SELECT * FROM investments 
        WHERE status = 'active' AND days_remaining > 0
      `)
        .all()

      for (const investment of activeInvestments.results) {
        // Adicionar lucro diário ao saldo do usuário
        await db
          .prepare(`
          UPDATE users 
          SET balance = balance + ? 
          WHERE id = ?
        `)
          .bind(investment.daily_profit, investment.user_id)
          .run()

        // Decrementar dias restantes
        const newDaysRemaining = investment.days_remaining - 1
        const newStatus = newDaysRemaining <= 0 ? "completed" : "active"

        await db
          .prepare(`
          UPDATE investments 
          SET days_remaining = ?, status = ?, updated_at = datetime('now')
          WHERE id = ?
        `)
          .bind(newDaysRemaining, newStatus, investment.id)
          .run()

        console.log(`Processado investimento ${investment.id} - Lucro: ${investment.daily_profit}kz`)
      }

      console.log(`Processados ${activeInvestments.results.length} investimentos`)
    } catch (error) {
      console.error("Erro ao processar lucros diários:", error)
    }
  },
}
