"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, TrendingUp } from "lucide-react"
import Link from "next/link"

interface User {
  id: string
  phone: string
  fullName: string
  balance: number
  inviteCode: string
  isAdmin?: boolean
}

const banks = ["BIC", "BFA", "BAI", "ATLÂNTICO"]

export default function WithdrawPage() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [withdrawAmount, setWithdrawAmount] = useState("")
  const [selectedBank, setSelectedBank] = useState("")
  const [bankAccount, setBankAccount] = useState("")
  const [message, setMessage] = useState("")
  const [messageType, setMessageType] = useState<"success" | "error">("success")

  useEffect(() => {
    const savedUser = localStorage.getItem("user")
    if (!savedUser) {
      router.push("/")
      return
    }
    const userData = JSON.parse(savedUser)
    setUser(userData)

    // Carregar dados bancários salvos
    setBankAccount(localStorage.getItem("bankAccount") || "")
    setSelectedBank(localStorage.getItem("selectedBank") || "")
  }, [router])

  const showMessage = (msg: string, type: "success" | "error" = "success") => {
    setMessage(msg)
    setMessageType(type)
    setTimeout(() => setMessage(""), 3000)
  }

  const formatCurrency = (value: number) => {
    return `${value.toLocaleString("pt-AO")}kz`
  }

  const handleWithdraw = () => {
    if (!user || !withdrawAmount || !selectedBank || !bankAccount) {
      showMessage("Preencha todos os campos", "error")
      return
    }

    const amount = Number.parseFloat(withdrawAmount)
    const minWithdraw = 1700
    const fee = 0.1

    if (amount < minWithdraw) {
      showMessage(`Saque mínimo é ${formatCurrency(minWithdraw)}`, "error")
      return
    }

    if (amount > user.balance) {
      showMessage("Saldo insuficiente", "error")
      return
    }

    // Criar solicitação de saque
    const withdrawal = {
      id: Math.random().toString(36).substring(2),
      userId: user.id,
      amount,
      bank: selectedBank,
      accountNumber: bankAccount,
      status: "pending",
      createdAt: new Date().toISOString(),
    }

    const savedWithdrawals = localStorage.getItem("withdrawals") || "[]"
    const withdrawals = JSON.parse(savedWithdrawals)
    withdrawals.push(withdrawal)
    localStorage.setItem("withdrawals", JSON.stringify(withdrawals))

    showMessage("Solicitação de saque enviada para aprovação")
    setWithdrawAmount("")
  }

  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">Carregando...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <h1 className="text-xl font-bold text-blue-600">Retirar Fundos</h1>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Saldo Atual</p>
              <p className="font-bold text-green-600">{formatCurrency(user.balance)}</p>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-6 w-6" />
              Retirar Fundos
            </CardTitle>
            <CardDescription>
              Saldo Disponível: <span className="font-semibold text-green-600">{formatCurrency(user.balance)}</span>
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="withdrawAmount">Valor a Retirar</Label>
              <Input
                id="withdrawAmount"
                type="number"
                placeholder="Digite o valor"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                className="h-12 text-lg"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="bank">Banco</Label>
              <Select
                value={selectedBank}
                onValueChange={(value) => {
                  setSelectedBank(value)
                  localStorage.setItem("selectedBank", value)
                }}
              >
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Selecione o banco" />
                </SelectTrigger>
                <SelectContent>
                  {banks.map((bank) => (
                    <SelectItem key={bank} value={bank}>
                      {bank}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="bankAccount">Conta Bancária</Label>
              <Input
                id="bankAccount"
                placeholder="Número da conta"
                value={bankAccount}
                onChange={(e) => {
                  setBankAccount(e.target.value)
                  localStorage.setItem("bankAccount", e.target.value)
                }}
                className="h-12"
              />
            </div>

            <Button onClick={handleWithdraw} className="w-full h-12 text-lg">
              Solicitar Saque
            </Button>

            <div className="bg-blue-50 p-4 rounded-lg">
              <h5 className="font-semibold mb-3">Informações Importantes:</h5>
              <ul className="space-y-2 text-sm text-gray-700">
                <li className="flex items-start">
                  <span className="text-blue-600 mr-2">•</span>
                  <span>Os saques são feitos de Segunda a Sexta-feira</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-600 mr-2">•</span>
                  <span>Horário de aprovação: 09h às 21h</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-600 mr-2">•</span>
                  <span>Aguarde aprovação do administrador</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-600 mr-2">•</span>
                  <span>Após aprovação: 30 minutos a 24h para receber</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-600 mr-2">•</span>
                  <span>Saque mínimo: {formatCurrency(1700)}</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-600 mr-2">•</span>
                  <span>Taxa: 10%</span>
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Message Toast */}
      {message && (
        <div className="fixed top-4 right-4 z-50">
          <Alert className={messageType === "error" ? "border-red-500 bg-red-50" : "border-green-500 bg-green-50"}>
            <AlertDescription className={messageType === "error" ? "text-red-700" : "text-green-700"}>
              {message}
            </AlertDescription>
          </Alert>
        </div>
      )}
    </div>
  )
}
