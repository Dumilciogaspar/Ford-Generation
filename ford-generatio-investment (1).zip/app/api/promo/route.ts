import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { userId, promoCode } = await request.json()

    // Verificar se o código promocional existe e está ativo
    // const db = env.DB
    // const promo = await db.prepare(`
    //   SELECT * FROM promo_codes
    //   WHERE code = ? AND active = true AND current_uses < max_uses
    //   AND (expires_at IS NULL OR expires_at > datetime('now'))
    // `).bind(promoCode).first()

    // if (!promo) {
    //   return NextResponse.json({ error: 'Código promocional inválido' }, { status: 400 })
    // }

    // Verificar se o usuário já usou este código
    // const alreadyUsed = await db.prepare(`
    //   SELECT id FROM promo_code_uses WHERE user_id = ? AND promo_code_id = ?
    // `).bind(userId, promo.id).first()

    // if (alreadyUsed) {
    //   return NextResponse.json({ error: 'Código já utilizado' }, { status: 400 })
    // }

    // Por enquanto, sempre retornar erro
    return NextResponse.json({ error: "Código promocional inválido" }, { status: 400 })
  } catch (error) {
    console.error("Erro no código promocional:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
