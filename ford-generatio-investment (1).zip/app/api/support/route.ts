import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { userId, message } = await request.json()

    if (!message.trim()) {
      return NextResponse.json({ error: "Mensagem não pode estar vazia" }, { status: 400 })
    }

    const messageId = Math.random().toString(36).substring(2)

    // Salvar mensagem no D1
    // const db = env.DB
    // await db.prepare(`
    //   INSERT INTO support_messages (id, user_id, message, sender)
    //   VALUES (?, ?, ?, 'user')
    // `).bind(messageId, userId, message).run()

    return NextResponse.json({
      success: true,
      messageId,
      message: "Mensagem enviada com sucesso",
    })
  } catch (error) {
    console.error("Erro ao enviar mensagem:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "ID do usuário é obrigatório" }, { status: 400 })
    }

    // Buscar mensagens do usuário
    // const db = env.DB
    // const messages = await db.prepare(`
    //   SELECT * FROM support_messages
    //   WHERE user_id = ?
    //   ORDER BY created_at ASC
    // `).bind(userId).all()

    // Por enquanto, retornar array vazio
    const messages = []

    return NextResponse.json({ messages })
  } catch (error) {
    console.error("Erro ao buscar mensagens:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
