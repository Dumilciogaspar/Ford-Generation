import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { userId, amount, bank, accountNumber } = await request.json()

    const minWithdraw = 1700
    const fee = 0.1

    if (amount < minWithdraw) {
      return NextResponse.json({ error: `Saque mínimo é ${minWithdraw}kz` }, { status: 400 })
    }

    // Verificar saldo do usuário
    // const db = env.DB
    // const user = await db.prepare(`SELECT balance FROM users WHERE id = ?`).bind(userId).first()

    const totalDeduction = amount + amount * fee

    // if (!user || user.balance < totalDeduction) {
    //   return NextResponse.json({ error: 'Saldo insuficiente' }, { status: 400 })
    // }

    const withdrawalId = Math.random().toString(36).substring(2)

    // Criar solicitação de saque
    // await db.prepare(`
    //   INSERT INTO withdrawals (id, user_id, amount, bank, account_number, status)
    //   VALUES (?, ?, ?, ?, ?, 'pending')
    // `).bind(withdrawalId, userId, amount, bank, accountNumber).run()

    // Atualizar saldo do usuário
    // await db.prepare(`
    //   UPDATE users SET balance = balance - ? WHERE id = ?
    // `).bind(totalDeduction, userId).run()

    return NextResponse.json({
      success: true,
      message: "O seu saque está sendo processado",
      withdrawalId,
    })
  } catch (error) {
    console.error("Erro no saque:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
