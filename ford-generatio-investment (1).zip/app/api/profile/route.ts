import { type NextRequest, NextResponse } from "next/server"

export async function PUT(request: NextRequest) {
  try {
    const { userId, fullName, phone, bankAccount, selectedBank } = await request.json()

    if (!userId || !fullName || !phone) {
      return NextResponse.json({ error: "Campos obrigatórios não preenchidos" }, { status: 400 })
    }

    if (!phone.startsWith("+244")) {
      return NextResponse.json({ error: "Número de telefone deve começar com +244" }, { status: 400 })
    }

    // Atualizar perfil no D1
    // const db = env.DB
    // await db.prepare(`
    //   UPDATE users
    //   SET full_name = ?, phone = ?, bank_account = ?, selected_bank = ?, updated_at = datetime('now')
    //   WHERE id = ?
    // `).bind(fullName, phone, bankAccount, selectedBank, userId).run()

    return NextResponse.json({
      success: true,
      message: "Perfil atualizado com sucesso",
    })
  } catch (error) {
    console.error("Erro ao atualizar perfil:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "ID do usuário é obrigatório" }, { status: 400 })
    }

    // Buscar dados do perfil
    // const db = env.DB
    // const user = await db.prepare(`
    //   SELECT id, phone, full_name, balance, invite_code, bank_account, selected_bank
    //   FROM users WHERE id = ?
    // `).bind(userId).first()

    // if (!user) {
    //   return NextResponse.json({ error: 'Usuário não encontrado' }, { status: 404 })
    // }

    // Por enquanto, retornar dados simulados
    const user = {
      id: userId,
      phone: "+244923456789",
      fullName: "Usuário Teste",
      balance: 50000,
      inviteCode: "ABC123",
      bankAccount: "",
      selectedBank: "",
    }

    return NextResponse.json({ user })
  } catch (error) {
    console.error("Erro ao buscar perfil:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
