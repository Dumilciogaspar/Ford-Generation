import { type NextRequest, NextResponse } from "next/server"
import bcrypt from "bcryptjs"

export async function POST(request: NextRequest) {
  try {
    const { phone, fullName, password, inviteCode } = await request.json()

    // Validar dados
    if (!phone.startsWith("+244")) {
      return NextResponse.json({ error: "Número de telefone deve começar com +244" }, { status: 400 })
    }

    if (!fullName || !password) {
      return NextResponse.json({ error: "Todos os campos são obrigatórios" }, { status: 400 })
    }

    // Hash da senha
    const passwordHash = await bcrypt.hash(password, 10)

    // Gerar código de convite único
    const generateInviteCode = () => {
      return Math.random().toString(36).substring(2, 8).toUpperCase()
    }

    const newInviteCode = generateInviteCode()
    const userId = Math.random().toString(36).substring(2)

    // Aqui você conectaria com o D1 database
    // const db = env.DB
    // await db.prepare(`
    //   INSERT INTO users (id, phone, full_name, password_hash, invite_code, referred_by)
    //   VALUES (?, ?, ?, ?, ?, ?)
    // `).bind(userId, phone, fullName, passwordHash, newInviteCode, inviteCode || null).run()

    // Por enquanto, simular resposta
    const user = {
      id: userId,
      phone,
      fullName,
      balance: 0,
      inviteCode: newInviteCode,
      referredBy: inviteCode || null,
    }

    return NextResponse.json({ user }, { status: 201 })
  } catch (error) {
    console.error("Erro no registro:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
