import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { phone, password } = await request.json()

    if (!phone.startsWith("+244")) {
      return NextResponse.json({ error: "Número de telefone deve começar com +244" }, { status: 400 })
    }

    // Aqui você buscaria no D1 database
    // const db = env.DB
    // const user = await db.prepare(`
    //   SELECT * FROM users WHERE phone = ?
    // `).bind(phone).first()

    // if (!user || !await bcrypt.compare(password, user.password_hash)) {
    //   return NextResponse.json(
    //     { error: 'Credenciais inválidas' },
    //     { status: 401 }
    //   )
    // }

    // Por enquanto, simular resposta
    const user = {
      id: "user123",
      phone,
      fullName: "Usuário Teste",
      balance: 50000,
      inviteCode: "ABC123",
    }

    return NextResponse.json({ user })
  } catch (error) {
    console.error("Erro no login:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
