import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { userId, packageValue, dailyProfit, totalProfit } = await request.json()

    // Aqui você verificaria o saldo do usuário no D1
    // const db = env.DB
    // const user = await db.prepare(`SELECT balance FROM users WHERE id = ?`).bind(userId).first()

    // if (!user || user.balance < packageValue) {
    //   return NextResponse.json({ error: 'Saldo insuficiente' }, { status: 400 })
    // }

    const investmentId = Math.random().toString(36).substring(2)

    // Criar investimento no D1
    // await db.prepare(`
    //   INSERT INTO investments (id, user_id, package_value, daily_profit, total_profit, days_remaining, days_total)
    //   VALUES (?, ?, ?, ?, ?, ?, ?)
    // `).bind(investmentId, userId, packageValue, dailyProfit, totalProfit, 90, 90).run()

    // Atualizar saldo do usuário
    // await db.prepare(`
    //   UPDATE users SET balance = balance - ? WHERE id = ?
    // `).bind(packageValue, userId).run()

    // Processar comissões para referenciadores
    // await processCommissions(userId, packageValue)

    return NextResponse.json({
      success: true,
      investmentId,
      message: "Investimento realizado com sucesso",
    })
  } catch (error) {
    console.error("Erro no investimento:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "ID do usuário é obrigatório" }, { status: 400 })
    }

    // Buscar investimentos do usuário no D1
    // const db = env.DB
    // const investments = await db.prepare(`
    //   SELECT * FROM investments WHERE user_id = ? ORDER BY created_at DESC
    // `).bind(userId).all()

    // Por enquanto, retornar dados simulados
    const investments = []

    return NextResponse.json({ investments })
  } catch (error) {
    console.error("Erro ao buscar investimentos:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
