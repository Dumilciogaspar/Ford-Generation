import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const userId = formData.get("userId") as string
    const amount = Number.parseFloat(formData.get("amount") as string)
    const method = formData.get("method") as string
    const proof = formData.get("proof") as File

    if (!userId || !amount || !method) {
      return NextResponse.json({ error: "Todos os campos são obrigatórios" }, { status: 400 })
    }

    if (amount < 1000) {
      return NextResponse.json({ error: "Depósito mínimo é 1.000kz" }, { status: 400 })
    }

    const depositId = Math.random().toString(36).substring(2)

    // Aqui você salvaria no D1 database
    // const db = env.DB
    // await db.prepare(`
    //   INSERT INTO deposits (id, user_id, amount, method, status, proof_filename)
    //   VALUES (?, ?, ?, ?, 'pending', ?)
    // `).bind(depositId, userId, amount, method, proof?.name || null).run()

    // Salvar arquivo de comprovativo no R2 ou KV
    // if (proof) {
    //   const buffer = await proof.arrayBuffer()
    //   await env.R2.put(`deposits/${depositId}/${proof.name}`, buffer)
    // }

    return NextResponse.json({
      success: true,
      depositId,
      message: "Depósito enviado para análise. Aguarde confirmação.",
    })
  } catch (error) {
    console.error("Erro no depósito:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "ID do usuário é obrigatório" }, { status: 400 })
    }

    // Buscar depósitos do usuário
    // const db = env.DB
    // const deposits = await db.prepare(`
    //   SELECT * FROM deposits WHERE user_id = ? ORDER BY created_at DESC
    // `).bind(userId).all()

    // Por enquanto, retornar array vazio
    const deposits = []

    return NextResponse.json({ deposits })
  } catch (error) {
    console.error("Erro ao buscar depósitos:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
