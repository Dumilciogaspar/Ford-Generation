"use client"

import { DialogDescription } from "@/components/ui/dialog"

import { DialogTitle } from "@/components/ui/dialog"

import { DialogHeader } from "@/components/ui/dialog"

import { DialogContent } from "@/components/ui/dialog"

import { Dialog } from "@/components/ui/dialog"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Gift, Users, Wallet, MessageCircle, LogOut, Eye, EyeOff } from "lucide-react"

interface User {
  id: string
  phone: string
  fullName: string
  balance: number
  inviteCode: string
  referredBy?: string
  isAdmin?: boolean
}

interface Investment {
  id: string
  userId: string
  packageValue: number
  dailyProfit: number
  totalProfit: number
  daysRemaining: number
  createdAt: string
}

interface InvestmentPackage {
  value: number
  dailyProfit: number
  totalProfit: number
  days: number
}

const investmentPackages: InvestmentPackage[] = [
  { value: 5000, dailyProfit: 1000, totalProfit: 90000, days: 90 },
  { value: 10000, dailyProfit: 2000, totalProfit: 180000, days: 90 },
  { value: 20000, dailyProfit: 4000, totalProfit: 360000, days: 90 },
  { value: 50000, dailyProfit: 10000, totalProfit: 900000, days: 90 },
  { value: 100000, dailyProfit: 20000, totalProfit: 1800000, days: 90 },
  { value: 200000, dailyProfit: 40000, totalProfit: 3600000, days: 90 },
  { value: 500000, dailyProfit: 100000, totalProfit: 9000000, days: 90 },
  { value: 1000000, dailyProfit: 200000, totalProfit: 18000000, days: 90 },
  { value: 2000000, dailyProfit: 400000, totalProfit: 36000000, days: 90 },
]

const banks = ["BIC", "BFA", "BAI", "ATLÂNTICO"]

export default function InvestmentPlatform() {
  const router = useRouter()
  const [currentView, setCurrentView] = useState<"auth" | "dashboard">("auth")
  const [authMode, setAuthMode] = useState<"login" | "register">("login")
  const [user, setUser] = useState<User | null>(null)
  const [showWelcome, setShowWelcome] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [message, setMessage] = useState("")
  const [messageType, setMessageType] = useState<"success" | "error">("success")
  const [investments, setInvestments] = useState<Investment[]>([])

  // Form states
  const [phone, setPhone] = useState("")
  const [fullName, setFullName] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [inviteCode, setInviteCode] = useState("")
  const [withdrawAmount, setWithdrawAmount] = useState("")
  const [selectedBank, setSelectedBank] = useState("")
  const [bankAccount, setBankAccount] = useState("")
  const [promoCode, setPromoCode] = useState("")
  const [supportMessage, setSupportMessage] = useState("")
  const [chatMessages, setChatMessages] = useState<
    Array<{ id: string; message: string; sender: "user" | "support"; timestamp: string }>
  >([])

  const [depositAmount, setDepositAmount] = useState("")
  const [depositMethod, setDepositMethod] = useState("")
  const [depositProof, setDepositProof] = useState<File | null>(null)
  const [profileData, setProfileData] = useState({
    fullName: "",
    phone: "",
    bankAccount: "",
    selectedBank: "",
  })

  useEffect(() => {
    // Simular carregamento de dados do usuário
    const savedUser = localStorage.getItem("user")
    if (savedUser) {
      const userData = JSON.parse(savedUser)
      setUser(userData)
      setCurrentView("dashboard")
      setShowWelcome(true)
      loadUserInvestments(userData.id)
      // Carregar dados do perfil
      setProfileData({
        fullName: userData.fullName,
        phone: userData.phone,
        bankAccount: localStorage.getItem("bankAccount") || "",
        selectedBank: localStorage.getItem("selectedBank") || "",
      })
    }
  }, [])

  useEffect(() => {
    // Verificar se já está logado
    const savedUser = localStorage.getItem("user")
    if (savedUser) {
      router.push("/dashboard")
    }
  }, [router])

  const showMessage = (msg: string, type: "success" | "error" = "success") => {
    setMessage(msg)
    setMessageType(type)
    setTimeout(() => setMessage(""), 3000)
  }

  const generateInviteCode = () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase()
  }

  const formatCurrency = (value: number) => {
    return `${value.toLocaleString("pt-AO")}kz`
  }

  const handleRegister = async () => {
    if (!phone.startsWith("+244")) {
      showMessage("Número de telefone deve começar com +244", "error")
      return
    }

    if (password !== confirmPassword) {
      showMessage("Senhas não coincidem", "error")
      return
    }

    if (!fullName || !password) {
      showMessage("Preencha todos os campos obrigatórios", "error")
      return
    }

    const newUser: User = {
      id: Math.random().toString(36).substring(2),
      phone,
      fullName,
      balance: 0,
      inviteCode: generateInviteCode(),
      referredBy: inviteCode || undefined,
      isAdmin: phone === "+244999999999", // Admin especial
    }

    // Simular salvamento no banco
    localStorage.setItem("user", JSON.stringify(newUser))
    setUser(newUser)
    setCurrentView("dashboard")
    setShowWelcome(true)
    showMessage("Conta criada com sucesso!")

    setTimeout(() => {
      router.push("/dashboard")
    }, 1000)
  }

  const handleLogin = async () => {
    if (!phone.startsWith("+244")) {
      showMessage("Número de telefone deve começar com +244", "error")
      return
    }

    // Simular login
    const savedUser = localStorage.getItem("user")
    if (savedUser) {
      const userData = JSON.parse(savedUser)
      if (userData.phone === phone) {
        setUser(userData)
        setCurrentView("dashboard")
        setShowWelcome(true)
        loadUserInvestments(userData.id)
        showMessage("Login realizado com sucesso!")
        setTimeout(() => {
          router.push("/dashboard")
        }, 1000)
        return
      }
    }

    // Login admin especial
    if (phone === "+244999999999" && password === "admin123") {
      const adminUser = {
        id: "admin",
        phone: "+244999999999",
        fullName: "Administrador",
        balance: 0,
        inviteCode: "ADMIN",
        isAdmin: true,
      }
      localStorage.setItem("user", JSON.stringify(adminUser))
      showMessage("Login de administrador realizado!")
      setTimeout(() => {
        router.push("/admin")
      }, 1000)
      return
    }

    showMessage("Credenciais inválidas", "error")
  }

  const loadUserInvestments = (userId: string) => {
    const savedInvestments = localStorage.getItem(`investments_${userId}`)
    if (savedInvestments) {
      setInvestments(JSON.parse(savedInvestments))
    }
  }

  const handleInvestment = (packageData: InvestmentPackage) => {
    if (!user) return

    if (user.balance < packageData.value) {
      showMessage("Saldo insuficiente", "error")
      return
    }

    const newInvestment: Investment = {
      id: Math.random().toString(36).substring(2),
      userId: user.id,
      packageValue: packageData.value,
      dailyProfit: packageData.dailyProfit,
      totalProfit: packageData.totalProfit,
      daysRemaining: packageData.days,
      createdAt: new Date().toISOString(),
    }

    const updatedUser = { ...user, balance: user.balance - packageData.value }
    const updatedInvestments = [...investments, newInvestment]

    setUser(updatedUser)
    setInvestments(updatedInvestments)

    localStorage.setItem("user", JSON.stringify(updatedUser))
    localStorage.setItem(`investments_${user.id}`, JSON.stringify(updatedInvestments))

    showMessage("Investimento realizado com sucesso!")
  }

  const handleWithdraw = () => {
    if (!user || !withdrawAmount || !selectedBank) {
      showMessage("Preencha todos os campos", "error")
      return
    }

    const amount = Number.parseFloat(withdrawAmount)
    const minWithdraw = 1700
    const fee = 0.1

    if (amount < minWithdraw) {
      showMessage(`Saque mínimo é ${formatCurrency(minWithdraw)}`, "error")
      return
    }

    if (amount > user.balance) {
      showMessage("Saldo insuficiente", "error")
      return
    }

    const totalDeduction = amount + amount * fee
    const updatedUser = { ...user, balance: user.balance - totalDeduction }

    setUser(updatedUser)
    localStorage.setItem("user", JSON.stringify(updatedUser))

    showMessage("O seu saque está sendo processado")
    setWithdrawAmount("")
    setSelectedBank("")
  }

  const handlePromoCode = () => {
    if (!promoCode) {
      showMessage("Digite um código promocional", "error")
      return
    }

    // Simular validação de código promocional
    showMessage("Código promocional inválido", "error")
    setPromoCode("")
  }

  const sendSupportMessage = () => {
    if (!supportMessage.trim()) return

    const newMessage = {
      id: Math.random().toString(36).substring(2),
      message: supportMessage,
      sender: "user" as const,
      timestamp: new Date().toLocaleTimeString(),
    }

    setChatMessages([...chatMessages, newMessage])
    setSupportMessage("")

    // Simular resposta automática do suporte
    setTimeout(() => {
      const supportResponse = {
        id: Math.random().toString(36).substring(2),
        message: "Obrigado pela sua mensagem. Nossa equipe entrará em contato em breve.",
        sender: "support" as const,
        timestamp: new Date().toLocaleTimeString(),
      }
      setChatMessages((prev) => [...prev, supportResponse])
    }, 1000)
  }

  const handleLogout = () => {
    localStorage.removeItem("user")
    setUser(null)
    setCurrentView("auth")
    setAuthMode("login")
    // Reset all form states
    setPhone("")
    setFullName("")
    setPassword("")
    setConfirmPassword("")
    setInviteCode("")
  }

  const handleDeposit = () => {
    if (!depositAmount) {
      showMessage("Preencha o valor do depósito", "error")
      return
    }

    const amount = Number.parseFloat(depositAmount)
    if (amount < 5000) {
      showMessage("Depósito mínimo é 5.000kz", "error")
      return
    }

    if (!depositProof) {
      showMessage("Envie o comprovativo de pagamento", "error")
      return
    }

    showMessage("Depósito enviado para análise. Aguarde confirmação.")
    setDepositAmount("")
    setDepositProof(null)
  }

  const handleProfileUpdate = () => {
    if (!profileData.fullName || !profileData.phone) {
      showMessage("Preencha os campos obrigatórios", "error")
      return
    }

    if (!profileData.phone.startsWith("+244")) {
      showMessage("Número de telefone deve começar com +244", "error")
      return
    }

    const updatedUser = {
      ...user!,
      fullName: profileData.fullName,
      phone: profileData.phone,
    }

    setUser(updatedUser)
    localStorage.setItem("user", JSON.stringify(updatedUser))
    showMessage("Perfil atualizado com sucesso!")
  }

  const loadProfileData = () => {
    if (user) {
      setProfileData({
        fullName: user.fullName,
        phone: user.phone,
        bankAccount: bankAccount,
        selectedBank: selectedBank,
      })
    }
  }

  if (currentView === "auth") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center p-4">
        <div className="w-full max-w-md space-y-6">
          <Card>
            <CardHeader className="text-center space-y-4">
              <CardTitle className="text-3xl font-bold text-blue-600">Ford-Generatio</CardTitle>
              <CardDescription className="text-lg">Plataforma de Investimento</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <Tabs value={authMode} onValueChange={(value) => setAuthMode(value as "login" | "register")}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="login">Entrar</TabsTrigger>
                  <TabsTrigger value="register">Cadastrar</TabsTrigger>
                </TabsList>

                <TabsContent value="login" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Número de Telefone</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+244..."
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="h-12"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Senha</Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="h-12 pr-12"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-12 px-3 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                  <Button onClick={handleLogin} className="w-full h-12 text-lg">
                    Entrar
                  </Button>
                </TabsContent>

                <TabsContent value="register" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone-reg">Número de Telefone</Label>
                    <Input
                      id="phone-reg"
                      type="tel"
                      placeholder="+244..."
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="h-12"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Nome Completo</Label>
                    <Input
                      id="fullName"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="h-12"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password-reg">Senha</Label>
                    <div className="relative">
                      <Input
                        id="password-reg"
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="h-12 pr-12"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-12 px-3 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirmar Senha</Label>
                    <div className="relative">
                      <Input
                        id="confirmPassword"
                        type={showConfirmPassword ? "text" : "password"}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="h-12 pr-12"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-12 px-3 hover:bg-transparent"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      >
                        {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="inviteCode">Código de Convite (Opcional)</Label>
                    <Input
                      id="inviteCode"
                      value={inviteCode}
                      onChange={(e) => setInviteCode(e.target.value)}
                      className="h-12"
                    />
                  </div>
                  <Button onClick={handleRegister} className="w-full h-12 text-lg">
                    Cadastrar
                  </Button>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="pt-6">
              <div className="text-center space-y-2">
                <p className="text-sm font-medium text-blue-800">Acesso Administrativo</p>
                <p className="text-xs text-blue-600">
                  Telefone: +244999999999
                  <br />
                  Senha: admin123
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {message && (
          <div className="fixed top-4 right-4 z-50">
            <Alert className={messageType === "error" ? "border-red-500 bg-red-50" : "border-green-500 bg-green-50"}>
              <AlertDescription className={messageType === "error" ? "text-red-700" : "text-green-700"}>
                {message}
              </AlertDescription>
            </Alert>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Welcome Dialog */}
      <Dialog open={showWelcome} onOpenChange={setShowWelcome}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Bem-vindo à Plataforma Ford-Generatio</DialogTitle>
            <DialogDescription className="text-sm space-y-2">
              <p>Plataforma de investimento de Produtos de Carro, opera nos Estados Unidos desde 2016.</p>
              <p>Convide pessoas e ganhará bónus de convite de:</p>
              <ul className="list-disc list-inside space-y-1">
                <li>Nível 1: 24%</li>
                <li>Nível 2: 4%</li>
                <li>Nível 3: 1%</li>
              </ul>
              <p>Em caso de dúvida contacta o nosso apoio ao cliente.</p>
            </DialogDescription>
          </DialogHeader>
          <Button onClick={() => setShowWelcome(false)} className="w-full">
            Obrigado
          </Button>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div>
              <h1 className="text-xl font-bold text-blue-600">Ford-Generatio</h1>
              <p className="text-sm text-gray-600">Olá, {user?.fullName}</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-gray-600">Saldo</p>
                <p className="font-bold text-green-600">{formatCurrency(user?.balance || 0)}</p>
              </div>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="investments" className="space-y-6">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="investments">Investimentos</TabsTrigger>
            <TabsTrigger value="deposit">Depósito</TabsTrigger>
            <TabsTrigger value="withdraw">Retirar</TabsTrigger>
            <TabsTrigger value="invite">Convites</TabsTrigger>
            <TabsTrigger value="promo">Prêmio</TabsTrigger>
            <TabsTrigger value="support">Apoio</TabsTrigger>
            <TabsTrigger value="profile">Perfil</TabsTrigger>
          </TabsList>

          {/* Investment Packages */}
          <TabsContent value="investments" className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {investmentPackages.map((pkg, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-lg">{formatCurrency(pkg.value)}</CardTitle>
                    <CardDescription>Pacote de Investimento</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Lucro Diário:</span>
                        <span className="font-semibold text-green-600">{formatCurrency(pkg.dailyProfit)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Duração:</span>
                        <span>{pkg.days} dias</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Lucro Total:</span>
                        <span className="font-semibold text-green-600">{formatCurrency(pkg.totalProfit)}</span>
                      </div>
                    </div>
                    <Button
                      onClick={() => handleInvestment(pkg)}
                      className="w-full"
                      disabled={!user || user.balance < pkg.value}
                    >
                      Investir
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Active Investments */}
            {investments.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Meus Investimentos</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  {investments.map((investment) => (
                    <Card key={investment.id}>
                      <CardHeader>
                        <CardTitle className="text-base">{formatCurrency(investment.packageValue)}</CardTitle>
                        <Badge variant="secondary">{investment.daysRemaining} dias restantes</Badge>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>Lucro Diário:</span>
                            <span className="text-green-600">{formatCurrency(investment.dailyProfit)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Lucro Total:</span>
                            <span className="text-green-600">{formatCurrency(investment.totalProfit)}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          {/* Deposit */}
          <TabsContent value="deposit" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wallet className="h-5 w-5" />
                  Fazer Depósito
                </CardTitle>
                <CardDescription>Adicione fundos à sua conta via Multicaixa Express</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="depositAmount">Valor do Depósito</Label>
                  <Input
                    id="depositAmount"
                    type="number"
                    placeholder="Digite o valor (mín. 5.000kz)"
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                  />
                </div>

                <div className="bg-blue-50 p-4 rounded-lg space-y-3">
                  <h4 className="font-semibold text-blue-800">Dados para Depósito - Multicaixa Express</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between items-center p-2 bg-white rounded border">
                      <span className="font-medium">Método:</span>
                      <span className="text-blue-600">Pagamento por Referência</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-white rounded border">
                      <span className="font-medium">Entidade:</span>
                      <span className="text-lg font-mono font-bold text-green-600">10116</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-white rounded border">
                      <span className="font-medium">Referência:</span>
                      <span className="text-lg font-mono font-bold text-green-600">956315864</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="depositProof">Comprovativo de Pagamento</Label>
                  <Input
                    id="depositProof"
                    type="file"
                    accept="image/*,.pdf"
                    onChange={(e) => setDepositProof(e.target.files?.[0] || null)}
                  />
                  <p className="text-sm text-gray-600">Envie o comprovativo do seu pagamento (imagem ou PDF)</p>
                </div>

                <Button onClick={handleDeposit} className="w-full">
                  Enviar Depósito
                </Button>

                <div className="bg-yellow-50 p-4 rounded-lg text-sm space-y-2">
                  <p className="font-semibold">Informações Importantes:</p>
                  <ul className="space-y-1 text-gray-700">
                    <li>
                      • <strong>Depósito mínimo: 5.000kz</strong>
                    </li>
                    <li>• Apenas via Multicaixa Express</li>
                    <li>• Use sempre a Entidade: 10116 e Referência: 956315864</li>
                    <li>• Processamento: 30 minutos a 24 horas</li>
                    <li>• Envie sempre o comprovativo</li>
                    <li>• Depósitos são processados de Segunda a Sexta</li>
                    <li>• Horário: 09h às 21h</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Withdraw */}
          <TabsContent value="withdraw" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wallet className="h-5 w-5" />
                  Retirar Fundos
                </CardTitle>
                <CardDescription>
                  Saldo Atual:{" "}
                  <span className="font-semibold text-green-600">{formatCurrency(user?.balance || 0)}</span>
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="withdrawAmount">Valor a Retirar</Label>
                  <Input
                    id="withdrawAmount"
                    type="number"
                    placeholder="Digite o valor"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bank">Banco</Label>
                  <Select value={selectedBank} onValueChange={setSelectedBank}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o banco" />
                    </SelectTrigger>
                    <SelectContent>
                      {banks.map((bank) => (
                        <SelectItem key={bank} value={bank}>
                          {bank}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bankAccount">Conta Bancária</Label>
                  <Input
                    id="bankAccount"
                    placeholder="Número da conta"
                    value={bankAccount}
                    onChange={(e) => setBankAccount(e.target.value)}
                  />
                </div>

                <Button onClick={handleWithdraw} className="w-full">
                  Levantar
                </Button>

                <div className="bg-blue-50 p-4 rounded-lg text-sm space-y-2">
                  <p className="font-semibold">Informações Importantes:</p>
                  <ul className="space-y-1 text-gray-700">
                    <li>• Os saques são feitos de Segunda a Sexta-feira</li>
                    <li>• Horário de Retirada: 09h às 21h</li>
                    <li>• Aguarde pacientemente, o valor chegará em sua conta num período de 30 minutos a 24h</li>
                    <li>• Saque mínimo: {formatCurrency(1700)}</li>
                    <li>• Taxa: 10%</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Invite System */}
          <TabsContent value="invite" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Sistema de Convites
                </CardTitle>
                <CardDescription>Convide pessoas e ganhe comissões</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg">
                  <p className="text-sm font-medium mb-2">Seu Código de Convite:</p>
                  <div className="flex items-center gap-2">
                    <code className="bg-white px-3 py-2 rounded border text-lg font-mono">{user?.inviteCode}</code>
                    <Button
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText(user?.inviteCode || "")
                        showMessage("Código copiado!")
                      }}
                    >
                      Copiar
                    </Button>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold">Comissões por Nível:</h4>
                  <div className="grid gap-2">
                    <div className="flex justify-between items-center p-3 bg-green-50 rounded">
                      <span>Nível 1 (Diretos)</span>
                      <Badge variant="secondary">24%</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-blue-50 rounded">
                      <span>Nível 2</span>
                      <Badge variant="secondary">4%</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-purple-50 rounded">
                      <span>Nível 3</span>
                      <Badge variant="secondary">1%</Badge>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-50 p-4 rounded-lg">
                  <p className="text-sm">
                    <strong>Link de Convite:</strong>
                    <br />
                    <code className="text-xs break-all">
                      {typeof window !== "undefined" ? window.location.origin : "https://ford-generatio.com"}?invite=
                      {user?.inviteCode}
                    </code>
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Promo Code */}
          <TabsContent value="promo" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gift className="h-5 w-5" />
                  Código Promocional
                </CardTitle>
                <CardDescription>Digite seu código promocional para receber prêmios</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="promoCode">Código Promocional</Label>
                  <Input
                    id="promoCode"
                    placeholder="Digite o código"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                  />
                </div>
                <Button onClick={handlePromoCode} className="w-full">
                  Submeter
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Support Chat */}
          <TabsContent value="support" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="h-5 w-5" />
                  Apoio ao Cliente
                </CardTitle>
                <CardDescription>Entre em contato conosco</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="h-64 border rounded-lg p-4 overflow-y-auto bg-gray-50">
                  {chatMessages.length === 0 ? (
                    <p className="text-gray-500 text-center">Nenhuma mensagem ainda. Inicie uma conversa!</p>
                  ) : (
                    <div className="space-y-3">
                      {chatMessages.map((msg) => (
                        <div key={msg.id} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                          <div
                            className={`max-w-xs px-3 py-2 rounded-lg text-sm ${
                              msg.sender === "user" ? "bg-blue-500 text-white" : "bg-white border"
                            }`}
                          >
                            <p>{msg.message}</p>
                            <p className={`text-xs mt-1 ${msg.sender === "user" ? "text-blue-100" : "text-gray-500"}`}>
                              {msg.timestamp}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Textarea
                    placeholder="Digite sua mensagem..."
                    value={supportMessage}
                    onChange={(e) => setSupportMessage(e.target.value)}
                    className="flex-1"
                    rows={2}
                  />
                  <Button onClick={sendSupportMessage} className="self-end">
                    Enviar
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile */}
          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Meu Perfil</CardTitle>
                <CardDescription>Gerencie suas informações pessoais</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="profileFullName">Nome Completo</Label>
                    <Input
                      id="profileFullName"
                      value={profileData.fullName}
                      onChange={(e) => setProfileData({ ...profileData, fullName: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="profilePhone">Telefone</Label>
                    <Input
                      id="profilePhone"
                      value={profileData.phone}
                      onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold">Informações Bancárias</h4>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="profileBank">Banco</Label>
                      <Select
                        value={profileData.selectedBank}
                        onValueChange={(value) => {
                          setProfileData({ ...profileData, selectedBank: value })
                          setSelectedBank(value)
                          localStorage.setItem("selectedBank", value)
                        }}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o banco" />
                        </SelectTrigger>
                        <SelectContent>
                          {banks.map((bank) => (
                            <SelectItem key={bank} value={bank}>
                              {bank}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="profileBankAccount">Número da Conta</Label>
                      <Input
                        id="profileBankAccount"
                        placeholder="Número da conta bancária"
                        value={profileData.bankAccount}
                        onChange={(e) => {
                          setProfileData({ ...profileData, bankAccount: e.target.value })
                          setBankAccount(e.target.value)
                          localStorage.setItem("bankAccount", e.target.value)
                        }}
                      />
                    </div>
                  </div>
                </div>

                <Button onClick={handleProfileUpdate} className="w-full">
                  Atualizar Perfil
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Estatísticas da Conta</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <p className="text-2xl font-bold text-green-600">{formatCurrency(user?.balance || 0)}</p>
                    <p className="text-sm text-gray-600">Saldo Atual</p>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <p className="text-2xl font-bold text-blue-600">{investments.length}</p>
                    <p className="text-sm text-gray-600">Investimentos Ativos</p>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <p className="text-2xl font-bold text-purple-600">{user?.inviteCode}</p>
                    <p className="text-sm text-gray-600">Código de Convite</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Histórico de Transações</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {investments.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">Nenhuma transação ainda</p>
                  ) : (
                    investments.map((investment) => (
                      <div key={investment.id} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                        <div>
                          <p className="font-medium">Investimento</p>
                          <p className="text-sm text-gray-600">{new Date(investment.createdAt).toLocaleDateString()}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-red-600">-{formatCurrency(investment.packageValue)}</p>
                          <p className="text-sm text-gray-600">Investimento</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Message Toast */}
      {message && (
        <div className="fixed top-4 right-4 z-50">
          <Alert className={messageType === "error" ? "border-red-500 bg-red-50" : "border-green-500 bg-green-50"}>
            <AlertDescription className={messageType === "error" ? "text-red-700" : "text-green-700"}>
              {message}
            </AlertDescription>
          </Alert>
        </div>
      )}
    </div>
  )
}
