"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert } from "@/components/ui/alert"
import { Shield, Users, Wallet, TrendingUp, CheckCircle, XCircle } from "lucide-react"

interface User {
  id: string
  phone: string
  fullName: string
  balance: number
  inviteCode: string
  isAdmin?: boolean
}

interface Deposit {
  id: string
  userId: string
  amount: number
  status: string
  proofName: string
  createdAt: string
}

interface Withdrawal {
  id: string
  userId: string
  amount: number
  bank: string
  accountNumber: string
  status: string
  createdAt: string
}

export default function AdminPage() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [deposits, setDeposits] = useState<Deposit[]>([])
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [message, setMessage] = useState("")
  const [messageType, setMessageType] = useState<"success" | "error">("success")

  useEffect(() => {
    const savedUser = localStorage.getItem("user")
    if (!savedUser) {
      router.push("/")
      return
    }

    const userData = JSON.parse(savedUser)
    if (!userData.isAdmin) {
      router.push("/dashboard")
      return
    }

    setUser(userData)
    loadData()
  }, [router])

  const loadData = () => {
    // Carregar depósitos
    const savedDeposits = localStorage.getItem("deposits") || "[]"
    setDeposits(JSON.parse(savedDeposits))

    // Carregar saques
    const savedWithdrawals = localStorage.getItem("withdrawals") || "[]"
    setWithdrawals(JSON.parse(savedWithdrawals))

    // Simular usuários (em produção viria do banco)
    const mockUsers = [
      { id: "1", phone: "+244923456789", fullName: "João Silva", balance: 15000, inviteCode: "ABC123" },
      { id: "2", phone: "+244987654321", fullName: "Maria Santos", balance: 8500, inviteCode: "DEF456" },
    ]
    setUsers(mockUsers)
  }

  const showMessage = (msg: string, type: "success" | "error" = "success") => {
    setMessage(msg)
    setMessageType(type)
    setTimeout(() => setMessage(""), 3000)
  }

  const formatCurrency = (value: number) => {
    return `${value.toLocaleString("pt-AO")}kz`
  }

  const approveDeposit = (depositId: string) => {
    const updatedDeposits = deposits.map(deposit => {
      if (deposit.id === depositId) {
        // Atualizar saldo do usuário
        const savedUser = localStorage.getItem("user")
        if (savedUser) {
          const userData = JSON.parse(savedUser)
          userData.balance += deposit.amount
          localStorage.setItem("user", JSON.stringify(userData))
        }
        
        return { ...deposit, status: "approved" }
      }
      return deposit
    })
    
    setDeposits(updatedDeposits)
    localStorage.setItem("deposits", JSON.stringify(updatedDeposits))
    showMessage("Depósito aprovado com sucesso!")
  }

  const rejectDeposit = (depositId: string) => {
    const updatedDeposits = deposits.map(deposit => 
      deposit.id === depositId ? { ...deposit, status: "rejected" } : deposit
    )
    
    setDeposits(updatedDeposits)
    localStorage.setItem("deposits", JSON.stringify(updatedDeposits))
    showMessage("Depósito rejeitado!")
  }

  const approveWithdrawal = (withdrawalId: string) => {
    const withdrawal = withdrawals.find(w => w.id === withdrawalId)
    if (!withdrawal) return

    const fee = withdrawal.amount * 0.1
    const totalDeduction = withdrawal.amount + fee

    // Atualizar saldo do usuário
    const savedUser = localStorage.getItem("user")
    if (savedUser) {
      const userData = JSON.parse(savedUser)
      userData.balance -= totalDeduction
      localStorage.setItem("user", JSON.stringify(userData))
    }

    const updatedWithdrawals = withdrawals.map(w => 
      w.id === withdrawalId ? { ...w, status: "approved" } : w
    )
    
    setWithdrawals(updatedWithdrawals)
    localStorage.setItem("withdrawals", JSON.stringify(updatedWithdrawals))
    showMessage("Saque aprovado com sucesso!")
  }

  const rejectWithdrawal = (withdrawalId: string) => {
    const updatedWithdrawals = withdrawals.map(w => 
      w.id === withdrawalId ? { ...w, status: "rejected" } : w
    )
    
    setWithdrawals(updatedWithdrawals)
    localStorage.setItem("withdrawals", JSON.stringify(updatedWithdrawals))
    showMessage("Saque rejeitado!")
  }

  const getUserName = (userId: string) => {
    const user = users.find(u => u.id === userId)
    return user ? user.fullName : "Usuário não encontrado"
  }

  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">Carregando...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Shield className="h-6 w-6 text-red-600" />
              <h1 className="text-xl font-bold text-red-600">Painel Administrativo</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Admin: {user.fullName}</span>
              <Button variant="outline" size="sm" onClick={() => router.push("/")}>
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="flex items-center p-6">
              <Users className="h-8 w-8 text-blue-600 mr-4" />
              <div>
                <p className="text-2xl font-bold">{users.length}</p>
                <p className="text-sm text-gray-600">Usuários</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex items-center p-6">
              <Wallet className="h-8 w-8 text-green-600 mr-4" />
              <div>
                <p className="text-2xl font-bold">{deposits.filter(d => d.status === "pending").length}</p>
                <p className="text-sm text-gray-600">Depósitos Pendentes</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex items-center p-6">
              <TrendingUp className="h-8 w-8 text-orange-600 mr-4" />
              <div>
                <p className="text-2xl font-bold">{withdrawals.filter(w => w.status === "pending").length}</p>
                <p className="text-sm text-gray-600">Saques Pendentes</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex items-center p-6">
              <Shield className="h-8 w-8 text-purple-600 mr-4" />
              <div>
                <p className="text-2xl font-bold">{deposits.length + withdrawals.length}</p>
                <p className="text-sm text-gray-600">Total Transações</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="deposits" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="deposits">Depósitos</TabsTrigger>
            <TabsTrigger value="withdrawals">Saques</TabsTrigger>
            <TabsTrigger value="users">Usuários</TabsTrigger>
          </TabsList>

          {/* Deposits Tab */}
          <TabsContent value="deposits" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Gerenciar Depósitos</CardTitle>
                <CardDescription>Aprovar ou rejeitar solicitações de depósito</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {deposits.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">Nenhum depósito encontrado</p>
                  ) : (
                    deposits.map((deposit) => (
                      <div key={deposit.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="space-y-1">
                          <p className="font-medium">{getUserName(deposit.userId)}</p>
                          <p className="text-sm text-gray-600">
                            Valor: <span className="font-semibold text-green-600">{formatCurrency(deposit.amount)}</span>
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(deposit.createdAt).toLocaleString()}
                          </p>
                          <p className="text-xs text-gray-500">
                            Comprovativo: {deposit.proofName}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge 
                            variant={
                              deposit.status === "approved" ? "default" : 
                              deposit.status === "rejected" ? "destructive" : 
                              "secondary"
                            }
                          >
                            {deposit.status === "pending" ? "Pendente" : 
                             deposit.status === "approved" ? "Aprovado" : "Rejeitado"}
                          </Badge>
                          {deposit.status === "pending" && (
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                onClick={() => approveDeposit(deposit.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Aprovar
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => rejectDeposit(deposit.id)}
                              >
                                <XCircle className="h-4 w-4 mr-1" />
                                Rejeitar
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Withdrawals Tab */}
          <TabsContent value="withdrawals" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Gerenciar Saques</CardTitle>
                <CardDescription>Aprovar ou rejeitar solicitações de saque</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {withdrawals.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">Nenhum saque encontrado</p>
                  ) : (
                    withdrawals.map((withdrawal) => (
                      <div key={withdrawal.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="space-y-1">
                          <p className="font-medium">{getUserName(withdrawal.userId)}</p>
                          <p className="text-sm text-gray-600">
                            Valor: <span className="font-semibold text-red-600">{formatCurrency(withdrawal.amount)}</span>
                          </p>
                          <p className="text-sm text-gray-600">
                            Banco: <span className="font-medium">{withdrawal.bank}</span>
                          </p>
                          <p className="text-sm text-gray-600">
                            Conta: <span className="font-mono">{withdrawal.accountNumber}</span>
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(withdrawal.createdAt).toLocaleString()}
                          </p>
                          <p className="text-xs text-orange-600">
                            Taxa (10%): {formatCurrency(withdrawal.amount * 0.1)}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge 
                            variant={
                              withdrawal.status === "approved" ? "default" : 
                              withdrawal.status === "rejected" ? "destructive" : 
                              "secondary"
                            }
                          >
                            {withdrawal.status === "pending" ? "Pendente" : 
                             withdrawal.status === "approved" ? "Aprovado" : "Rejeitado"}
                          </Badge>
                          {withdrawal.status === "pending" && (
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                onClick={() => approveWithdrawal(withdrawal.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Aprovar
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => rejectWithdrawal(withdrawal.id)}
                              >
                                <XCircle className="h-4 w-4 mr-1" />
                                Rejeitar
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Usuários Registrados</CardTitle>
                <CardDescription>Lista de todos os usuários da plataforma</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {users.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="space-y-1">
                        <p className="font-medium">{user.fullName}</p>
                        <p className="text-sm text-gray-600">{user.phone}</p>
                        <p className="text-sm text-gray-600">
                          Código: <span className="font-mono">{user.inviteCode}</span>
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-green-600">{formatCurrency(user.balance)}</p>
                        <p className="text-xs text-gray-500">Saldo</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Message Toast */}
      {message && (
        <div className="fixed top-4 right-4 z-50">
          <Alert className={messageType === "error" ? "border-red-500 bg-red-50" : "border-green-500 bg-green-50"}>
            \
