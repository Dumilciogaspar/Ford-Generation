"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, Wallet } from "lucide-react"
import Link from "next/link"

interface User {
  id: string
  phone: string
  fullName: string
  balance: number
  inviteCode: string
  isAdmin?: boolean
}

export default function DepositPage() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [depositAmount, setDepositAmount] = useState("")
  const [depositProof, setDepositProof] = useState<File | null>(null)
  const [message, setMessage] = useState("")
  const [messageType, setMessageType] = useState<"success" | "error">("success")

  useEffect(() => {
    const savedUser = localStorage.getItem("user")
    if (!savedUser) {
      router.push("/")
      return
    }
    setUser(JSON.parse(savedUser))
  }, [router])

  const showMessage = (msg: string, type: "success" | "error" = "success") => {
    setMessage(msg)
    setMessageType(type)
    setTimeout(() => setMessage(""), 3000)
  }

  const formatCurrency = (value: number) => {
    return `${value.toLocaleString("pt-AO")}kz`
  }

  const handleDeposit = () => {
    if (!depositAmount) {
      showMessage("Preencha o valor do depósito", "error")
      return
    }

    const amount = Number.parseFloat(depositAmount)
    if (amount < 5000) {
      showMessage("Depósito mínimo é 5.000kz", "error")
      return
    }

    if (!depositProof) {
      showMessage("Envie o comprovativo de pagamento", "error")
      return
    }

    // Simular salvamento do depósito
    const deposit = {
      id: Math.random().toString(36).substring(2),
      userId: user?.id,
      amount,
      status: "pending",
      proofName: depositProof.name,
      createdAt: new Date().toISOString(),
    }

    const savedDeposits = localStorage.getItem("deposits") || "[]"
    const deposits = JSON.parse(savedDeposits)
    deposits.push(deposit)
    localStorage.setItem("deposits", JSON.stringify(deposits))

    showMessage("Depósito enviado para análise. Aguarde confirmação.")
    setDepositAmount("")
    setDepositProof(null)

    // Reset file input
    const fileInput = document.getElementById("depositProof") as HTMLInputElement
    if (fileInput) fileInput.value = ""
  }

  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">Carregando...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <h1 className="text-xl font-bold text-blue-600">Fazer Depósito</h1>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Saldo Atual</p>
              <p className="font-bold text-green-600">{formatCurrency(user.balance)}</p>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wallet className="h-6 w-6" />
              Fazer Depósito
            </CardTitle>
            <CardDescription>Adicione fundos à sua conta via Multicaixa Express</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="depositAmount">Valor do Depósito</Label>
              <Input
                id="depositAmount"
                type="number"
                placeholder="Digite o valor (mín. 5.000kz)"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                className="h-12 text-lg"
              />
            </div>

            <div className="bg-blue-50 p-6 rounded-lg space-y-4">
              <h4 className="font-semibold text-blue-800 text-lg">Dados para Depósito - Multicaixa Express</h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-white rounded border">
                  <span className="font-medium">Método:</span>
                  <span className="text-blue-600 font-semibold">Pagamento por Referência</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-white rounded border">
                  <span className="font-medium">Entidade:</span>
                  <span className="text-2xl font-mono font-bold text-green-600">10116</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-white rounded border">
                  <span className="font-medium">Referência:</span>
                  <span className="text-2xl font-mono font-bold text-green-600">956315864</span>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="depositProof">Comprovativo de Pagamento</Label>
              <Input
                id="depositProof"
                type="file"
                accept="image/*,.pdf"
                onChange={(e) => setDepositProof(e.target.files?.[0] || null)}
                className="h-12"
              />
              <p className="text-sm text-gray-600">Envie o comprovativo do seu pagamento (imagem ou PDF)</p>
            </div>

            <Button onClick={handleDeposit} className="w-full h-12 text-lg">
              Enviar Depósito
            </Button>

            <div className="bg-yellow-50 p-4 rounded-lg">
              <h5 className="font-semibold mb-3">Informações Importantes:</h5>
              <ul className="space-y-2 text-sm text-gray-700">
                <li className="flex items-start">
                  <span className="text-yellow-600 mr-2">•</span>
                  <span>
                    <strong>Depósito mínimo: 5.000kz</strong>
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-yellow-600 mr-2">•</span>
                  <span>Apenas via Multicaixa Express</span>
                </li>
                <li className="flex items-start">
                  <span className="text-yellow-600 mr-2">•</span>
                  <span>
                    Use sempre a Entidade: <strong>10116</strong> e Referência: <strong>956315864</strong>
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-yellow-600 mr-2">•</span>
                  <span>Processamento: 30 minutos a 24 horas</span>
                </li>
                <li className="flex items-start">
                  <span className="text-yellow-600 mr-2">•</span>
                  <span>Envie sempre o comprovativo</span>
                </li>
                <li className="flex items-start">
                  <span className="text-yellow-600 mr-2">•</span>
                  <span>Depósitos são processados de Segunda a Sexta</span>
                </li>
                <li className="flex items-start">
                  <span className="text-yellow-600 mr-2">•</span>
                  <span>Horário: 09h às 21h</span>
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Message Toast */}
      {message && (
        <div className="fixed top-4 right-4 z-50">
          <Alert className={messageType === "error" ? "border-red-500 bg-red-50" : "border-green-500 bg-green-50"}>
            <AlertDescription className={messageType === "error" ? "text-red-700" : "text-green-700"}>
              {message}
            </AlertDescription>
          </Alert>
        </div>
      )}
    </div>
  )
}
