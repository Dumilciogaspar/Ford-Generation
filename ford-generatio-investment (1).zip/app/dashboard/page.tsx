"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Wallet, Users, Gift, MessageCircle, LogOut, TrendingUp } from "lucide-react"
import Link from "next/link"

interface Investment {
  id: string
  userId: string
  packageValue: number
  dailyProfit: number
  totalProfit: number
  daysRemaining: number
  createdAt: string
}

interface InvestmentPackage {
  value: number
  dailyProfit: number
  totalProfit: number
  days: number
}

const investmentPackages: InvestmentPackage[] = [
  { value: 5000, dailyProfit: 1000, totalProfit: 90000, days: 90 },
  { value: 10000, dailyProfit: 2000, totalProfit: 180000, days: 90 },
  { value: 20000, dailyProfit: 4000, totalProfit: 360000, days: 90 },
  { value: 50000, dailyProfit: 10000, totalProfit: 900000, days: 90 },
  { value: 100000, dailyProfit: 20000, totalProfit: 1800000, days: 90 },
  { value: 200000, dailyProfit: 40000, totalProfit: 3600000, days: 90 },
  { value: 500000, dailyProfit: 100000, totalProfit: 9000000, days: 90 },
  { value: 1000000, dailyProfit: 200000, totalProfit: 18000000, days: 90 },
  { value: 2000000, dailyProfit: 400000, totalProfit: 36000000, days: 90 },
]

interface UserData {
  id: string
  phone: string
  fullName: string
  balance: number
  inviteCode: string
  referredBy?: string
  isAdmin?: boolean
}

export default function Dashboard() {
  const router = useRouter()
  const [userData, setUserData] = useState<UserData | null>(null)
  const [showWelcome, setShowWelcome] = useState(false)
  const [investments, setInvestments] = useState<Investment[]>([])
  const [message, setMessage] = useState("")
  const [messageType, setMessageType] = useState<"success" | "error">("success")

  useEffect(() => {
    const savedUser = localStorage.getItem("user")
    if (!savedUser) {
      router.push("/")
      return
    }

    const userData = JSON.parse(savedUser)
    setUserData(userData)
    setShowWelcome(true)
    loadUserInvestments(userData.id)
  }, [router])

  const showMessage = (msg: string, type: "success" | "error" = "success") => {
    setMessage(msg)
    setMessageType(type)
    setTimeout(() => setMessage(""), 2000)
  }

  const formatCurrency = (value: number) => {
    return `${value.toLocaleString("pt-AO")}kz`
  }

  const loadUserInvestments = (userId: string) => {
    const savedInvestments = localStorage.getItem(`investments_${userId}`)
    if (savedInvestments) {
      setInvestments(JSON.parse(savedInvestments))
    }
  }

  const handleInvestment = (packageData: InvestmentPackage) => {
    if (!userData) return

    if (userData.balance < packageData.value) {
      showMessage("Saldo insuficiente", "error")
      return
    }

    const newInvestment: Investment = {
      id: Math.random().toString(36).substring(2),
      userId: userData.id,
      packageValue: packageData.value,
      dailyProfit: packageData.dailyProfit,
      totalProfit: packageData.totalProfit,
      daysRemaining: packageData.days,
      createdAt: new Date().toISOString(),
    }

    const updatedUserData = { ...userData, balance: userData.balance - packageData.value }
    const updatedInvestments = [...investments, newInvestment]

    setUserData(updatedUserData)
    setInvestments(updatedInvestments)

    localStorage.setItem("user", JSON.stringify(updatedUserData))
    localStorage.setItem(`investments_${userData.id}`, JSON.stringify(updatedInvestments))

    showMessage("Investimento realizado com sucesso!")
  }

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  if (!userData) {
    return <div className="min-h-screen flex items-center justify-center">Carregando...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Welcome Dialog */}
      <Dialog open={showWelcome} onOpenChange={setShowWelcome}>
        <DialogContent className="max-w-md mx-4">
          <DialogHeader>
            <DialogTitle className="text-center">Bem-vindo à Plataforma Ford-Generatio</DialogTitle>
            <DialogDescription className="text-sm space-y-3 text-center">
              <p>Plataforma de investimento de Produtos de Carro, opera nos Estados Unidos desde 2016.</p>
              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="font-medium">Convide pessoas e ganhará bónus de convite:</p>
                <ul className="space-y-1 mt-2">
                  <li>• Nível 1: 24%</li>
                  <li>• Nível 2: 4%</li>
                  <li>• Nível 3: 1%</li>
                </ul>
              </div>
              <p className="text-xs">Em caso de dúvida contacta o nosso apoio ao cliente.</p>
            </DialogDescription>
          </DialogHeader>
          <Button onClick={() => setShowWelcome(false)} className="w-full">
            Obrigado
          </Button>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div>
              <h1 className="text-xl font-bold text-blue-600">Ford-Generatio</h1>
              <p className="text-sm text-gray-600">Olá, {userData.fullName}</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-gray-600">Saldo</p>
                <p className="font-bold text-green-600">{formatCurrency(userData.balance)}</p>
              </div>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Navigation Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Link href="/deposit">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="flex flex-col items-center justify-center p-6 space-y-2">
                <Wallet className="h-8 w-8 text-blue-600" />
                <span className="font-medium text-center">Depósito</span>
              </CardContent>
            </Card>
          </Link>

          <Link href="/withdraw">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="flex flex-col items-center justify-center p-6 space-y-2">
                <TrendingUp className="h-8 w-8 text-green-600" />
                <span className="font-medium text-center">Retirar</span>
              </CardContent>
            </Card>
          </Link>

          <Link href="/invite">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="flex flex-col items-center justify-center p-6 space-y-2">
                <Users className="h-8 w-8 text-purple-600" />
                <span className="font-medium text-center">Convites</span>
              </CardContent>
            </Card>
          </Link>

          <Link href="/support">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="flex flex-col items-center justify-center p-6 space-y-2">
                <MessageCircle className="h-8 w-8 text-orange-600" />
                <span className="font-medium text-center">Apoio</span>
              </CardContent>
            </Card>
          </Link>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Link href="/promo">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="flex flex-col items-center justify-center p-6 space-y-2">
                <Gift className="h-8 w-8 text-red-600" />
                <span className="font-medium text-center">Prêmio</span>
              </CardContent>
            </Card>
          </Link>

          <Link href="/profile">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="flex flex-col items-center justify-center p-6 space-y-2">
                <LogOut className="h-8 w-8 text-gray-600" />
                <span className="font-medium text-center">Perfil</span>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Investment Packages */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-center">Pacotes de Investimento</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {investmentPackages.map((pkg, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl text-center">{formatCurrency(pkg.value)}</CardTitle>
                  <CardDescription className="text-center">Pacote de Investimento</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between items-center p-2 bg-green-50 rounded">
                      <span>Lucro Diário:</span>
                      <span className="font-semibold text-green-600">{formatCurrency(pkg.dailyProfit)}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-blue-50 rounded">
                      <span>Duração:</span>
                      <span className="font-semibold">{pkg.days} dias</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-purple-50 rounded">
                      <span>Lucro Total:</span>
                      <span className="font-semibold text-purple-600">{formatCurrency(pkg.totalProfit)}</span>
                    </div>
                  </div>
                  <Button
                    onClick={() => handleInvestment(pkg)}
                    className="w-full h-12"
                    disabled={userData.balance < pkg.value}
                  >
                    {userData.balance < pkg.value ? "Saldo Insuficiente" : "Investir"}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Active Investments */}
        {investments.length > 0 && (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold">Meus Investimentos Ativos</h3>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {investments.map((investment) => (
                <Card key={investment.id}>
                  <CardHeader className="pb-4">
                    <CardTitle className="text-lg">{formatCurrency(investment.packageValue)}</CardTitle>
                    <Badge variant="secondary" className="w-fit">
                      {investment.daysRemaining} dias restantes
                    </Badge>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Lucro Diário:</span>
                        <span className="text-green-600 font-medium">{formatCurrency(investment.dailyProfit)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Lucro Total:</span>
                        <span className="text-green-600 font-medium">{formatCurrency(investment.totalProfit)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Data:</span>
                        <span>{new Date(investment.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Message Toast */}
      {message && (
        <div className="fixed top-4 right-4 z-50">
          <div
            className={`p-4 rounded-lg shadow-lg ${messageType === "error" ? "bg-red-50 border border-red-200" : "bg-green-50 border border-green-200"}`}
          >
            <p className={messageType === "error" ? "text-red-700" : "text-green-700"}>{message}</p>
          </div>
        </div>
      )}
    </div>
  )
}
